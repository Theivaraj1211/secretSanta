const express = require('express');
const multer = require('multer');
const { processSecretSanta } = require('../controller/secretSantaController');

const router = express.Router();
const upload = multer({ dest: 'uploads/' });

router.post(
    '/assign-secret-santa',
    upload.fields([
        { name: 'employees', maxCount: 1 },
        { name: 'lastYear', maxCount: 1 },
    ]),
    processSecretSanta
);

module.exports = router;
