const express = require('express');
const secretSantaRoutes = require('../ssg/router/secretSantaRouter');

const app = express();
const PORT = process.env.PORT || 3000;

app.use('/api', secretSantaRoutes);

app.use((req, res) => {
    res.status(404).json({ error: 'Endpoint not found.' });
});

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
