const fs = require('fs');
const path = require('path');
const csvParser = require('csv-parser');
const fastCsv = require('fast-csv');

// Helper to read CSV file
const readCSV = (filePath) => {
  return new Promise((resolve, reject) => {
    const data = [];
    fs.createReadStream(filePath)
      .pipe(csvParser())
      .on('data', (row) => data.push(row))
      .on('end', () => {
        if (data.length === 0) {
          return reject(new Error('CSV file is empty.'));
        }
        resolve(data);
      })
      .on('error', (error) => reject(new Error(`Error reading CSV: ${error.message}`)));
  });
};

// Helper to write CSV file
const writeCSV = (assignments, outputPath) => {
  return new Promise((resolve, reject) => {
    const csvStream = fastCsv.format({ headers: true });
    const writableStream = fs.createWriteStream(outputPath);

    writableStream.on('finish', resolve);
    writableStream.on('error', (error) => reject(new Error(`Error writing CSV: ${error.message}`)));

    csvStream.pipe(writableStream);
    assignments.forEach((row) => csvStream.write(row));
    csvStream.end();
  });
};

// Secret Santa Assignment Logic
const assignSecretSantas = (employees, lastYearAssignments) => {
  const lastYearMap = new Map(
    lastYearAssignments.map(({ Employee_EmailID, Secret_Child_EmailID }) => [
      Employee_EmailID,
      Secret_Child_EmailID,
    ])
  );

  const availableChildren = [...employees];
  const assignments = [];

  for (const employee of employees) {
    const potentialChildren = availableChildren.filter(
      (child) =>
        child.Employee_EmailID !== employee.Employee_EmailID &&
        lastYearMap.get(employee.Employee_EmailID) !== child.Employee_EmailID
    );

    if (potentialChildren.length === 0) {
      throw new Error(`No valid assignment for ${employee.Employee_Name}.`);
    }

    const randomIndex = Math.floor(Math.random() * potentialChildren.length);
    const chosenChild = potentialChildren[randomIndex];

    assignments.push({
      Employee_Name: employee.Employee_Name,
      Employee_EmailID: employee.Employee_EmailID,
      Secret_Child_Name: chosenChild.Employee_Name,
      Secret_Child_EmailID: chosenChild.Employee_EmailID,
    });

    availableChildren.splice(availableChildren.indexOf(chosenChild), 1);
  }

  return assignments;
};

// Controller Function: Process Secret Santa Assignment
const processSecretSanta = async (req, res) => {
  try {
    // Validate that both files were uploaded
    const employeesFile = req.files?.['employees']?.[0];
    const lastYearFile = req.files?.['lastYear']?.[0];

    if (!employeesFile || !lastYearFile) {
      return res.status(400).json({ error: 'Both CSV files are required.' });
    }

    // Read and parse the uploaded CSV files
    const employees = await readCSV(employeesFile.path);
    const lastYearAssignments = await readCSV(lastYearFile.path);

    if (employees.length < 2) {
      return res.status(400).json({ error: 'At least 2 employees are required for Secret Santa.' });
    }

    // Perform Secret Santa assignments
    const newAssignments = assignSecretSantas(employees, lastYearAssignments);

    // Define output path for the new CSV file
    //const outputPath = path.join(__dirname, '../uploads/new_assignments.csv');
    const outputPath = path.join(__dirname, '../uploads/')
    await writeCSV(newAssignments, outputPath);

    // Send the generated CSV file as a download response
    res.status(200).download(outputPath, 'new_assignments.csv', (err) => {
      if (err) {
        console.error('Error sending file:', err);
        return res.status(500).json({ error: 'Failed to download the CSV file.' });
      }

      // Cleanup: Delete the uploaded and generated files
      fs.unlinkSync(employeesFile.path);
      fs.unlinkSync(lastYearFile.path);
      fs.unlinkSync(outputPath);
    });
  } catch (error) {
    console.error('Error:', error);

    if (error.message.includes('No valid assignment')) {
      return res.status(404).json({ error: error.message });
    }

    res.status(500).json({ error: 'Internal Server Error. Please try again.' });
  }
};

module.exports = { processSecretSanta };
